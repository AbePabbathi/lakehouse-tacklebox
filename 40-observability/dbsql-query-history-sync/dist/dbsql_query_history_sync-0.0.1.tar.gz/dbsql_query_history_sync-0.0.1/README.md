Sync a Delta table with the query history from a dbsql warehouse.

As easy as:

```
# create the object
udbq = UpdateDBQueries(dbx_token=DBX_TOKEN, 
                       warehouse_ids=warehouse_ids_list, earliest_query_ts_ms=dt_ts, table_name=sync_table)
udbq.update_db_repeat(interval_secs=10)
```

See dbsql_query_sync_example.py.

For questions contact nishant.deshpande@databricks.com.

